import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();
  factory SupabaseService() => _instance;
  SupabaseService._internal();

  final client = Supabase.instance.client;

  Future<LauncherConfig> getConfig() async {
    final response = await client.from('launcher_config').select().single();
    return LauncherConfig.fromJson(response);
  }
}

class AuthService {
  final _client = Supabase.instance.client;

  Future<AuthResponse> signIn(String email, String password) async {
    return await _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<AuthResponse> signUp(String email, String password, String name) async {
    final res = await _client.auth.signUp(email: email, password: password, data: {'name': name});
    if (res.user != null) {
      await _client.from('users').insert({
        'id': res.user!.id,
        'email': email,
        'name': name,
        'role': 'client',
      });
    }
    return res;
  }

  Future<void> signOut() async => await _client.auth.signOut();

  User? get currentUser => _client.auth.currentUser;
}

class DownloadService {
  final Dio _dio = Dio();

  Future<void> downloadFile(String url, String savePath, Function(int, int) onProgress) async {
    await _dio.download(
      url,
      savePath,
      onReceiveProgress: onProgress,
    );
  }

  Future<String> getLocalPath() async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }
}

class FileService {
  Future<void> createFolderStructure() async {
    final baseDir = await getApplicationDocumentsDirectory();
    final folders = [
      'gta', 'gta/samp', 'gta/data', 'gta/models', 'gta/audio', 
      'gta/cleo', 'gta/textures', 'gta/config', 'gta/mods'
    ];
    
    for (var folder in folders) {
      final dir = Directory('${baseDir.path}/$folder');
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }
    }
  }
}
