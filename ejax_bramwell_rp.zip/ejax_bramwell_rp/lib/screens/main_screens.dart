import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/gamer_widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const HeaderWidget(),
              const SizedBox(height: 20),
              const BannerWidget(),
              const SizedBox(height: 30),
              const Text(
                'MENU PRINCIPAL',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.primaryColor),
              ),
              const SizedBox(height: 15),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 15,
                crossAxisSpacing: 15,
                children: [
                  MenuCard(
                    title: 'JOGAR',
                    icon: Icons.play_arrow_rounded,
                    color: AppTheme.primaryColor,
                    onTap: () {},
                  ),
                  MenuCard(
                    title: 'SERVIDORES',
                    icon: Icons.dns_rounded,
                    color: AppTheme.secondaryColor,
                    onTap: () => Navigator.pushNamed(context, '/servers'),
                  ),
                  MenuCard(
                    title: 'DOWNLOADS',
                    icon: Icons.download_rounded,
                    color: Colors.greenAccent,
                    onTap: () => Navigator.pushNamed(context, '/downloads'),
                  ),
                  MenuCard(
                    title: 'PERFIL',
                    icon: Icons.person_rounded,
                    color: AppTheme.accentColor,
                    onTap: () => Navigator.pushNamed(context, '/profile'),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              const Text(
                'NOTÍCIAS RECENTES',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.primaryColor),
              ),
              const SizedBox(height: 15),
              const NewsCard(
                title: 'Novo Sistema de Empregos!',
                description: 'Confira as novidades do servidor EJAX BRAMWELL RP.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ServersScreen extends StatelessWidget {
  const ServersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SERVIDORES'), backgroundColor: Colors.transparent),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          ServerListItem(
            name: 'EJAX BRAMWELL RP #1',
            ip: '127.0.0.1',
            port: 7777,
            status: 'ONLINE',
            players: '150/500',
          ),
        ],
      ),
    );
  }
}

class DownloadsScreen extends StatefulWidget {
  const DownloadsScreen({super.key});

  @override
  State<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends State<DownloadsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DOWNLOADS'), backgroundColor: Colors.transparent),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          DownloadItemWidget(
            name: 'Data SAMP Obrigatória',
            size: '450 MB',
            progress: 0.75,
            status: 'Baixando...',
          ),
          DownloadItemWidget(
            name: 'GTA San Andreas (Base)',
            size: '1.8 GB',
            progress: 1.0,
            status: 'Concluído',
          ),
        ],
      ),
    );
  }
}
