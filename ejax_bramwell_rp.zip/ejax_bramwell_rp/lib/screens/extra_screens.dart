import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/services.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = AuthService().currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('MEU PERFIL'), backgroundColor: Colors.transparent),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(radius: 50, backgroundColor: AppTheme.primaryColor, child: Icon(Icons.person, size: 50, color: Colors.black)),
            const SizedBox(height: 20),
            Text(user?.email ?? 'Usuário', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text('Role: Client', style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 30),
            ListTile(
              leading: const Icon(Icons.settings, color: AppTheme.primaryColor),
              title: const Text('Configurações'),
              onTap: () => Navigator.pushNamed(context, '/settings'),
            ),
            ListTile(
              leading: const Icon(Icons.admin_panel_settings, color: AppTheme.secondaryColor),
              title: const Text('Painel Admin'),
              onTap: () => Navigator.pushNamed(context, '/admin'),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () async {
                await AuthService().signOut();
                Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
              child: const Text('SAIR DA CONTA'),
            ),
          ],
        ),
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CONFIGURAÇÕES'), backgroundColor: Colors.transparent),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          SwitchListTile(title: const Text('Notificações'), value: true, onChanged: (v) {}, activeColor: AppTheme.primaryColor),
          SwitchListTile(title: const Text('Auto-Update'), value: true, onChanged: (v) {}, activeColor: AppTheme.primaryColor),
          ListTile(title: const Text('Limpar Cache'), trailing: const Icon(Icons.delete_outline), onTap: () {}),
          ListTile(title: const Text('Sobre o Launcher'), subtitle: const Text('Versão 1.0.0'), onTap: () {}),
        ],
      ),
    );
  }
}

class AdminPanelScreen extends StatelessWidget {
  const AdminPanelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PAINEL ADMIN'), backgroundColor: Colors.transparent),
      body: GridView.count(
        padding: const EdgeInsets.all(20),
        crossAxisCount: 2,
        mainAxisSpacing: 15,
        crossAxisSpacing: 15,
        children: [
          _AdminCard(title: 'USUÁRIOS', icon: Icons.people, color: Colors.blue),
          _AdminCard(title: 'SERVIDORES', icon: Icons.dns, color: Colors.orange),
          _AdminCard(title: 'NOTÍCIAS', icon: Icons.newspaper, color: Colors.green),
          _AdminCard(title: 'ARQUIVOS', icon: Icons.file_copy, color: Colors.purple),
          _AdminCard(title: 'MANUTENÇÃO', icon: Icons.build, color: Colors.red),
          _AdminCard(title: 'CONFIGS', icon: Icons.settings, color: Colors.grey),
        ],
      ),
    );
  }
}

class _AdminCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;

  const _AdminCard({required this.title, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: AppTheme.surfaceColor, borderRadius: BorderRadius.circular(15), border: Border.all(color: color.withOpacity(0.3))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 40, color: color),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        ],
      ),
    );
  }
}
