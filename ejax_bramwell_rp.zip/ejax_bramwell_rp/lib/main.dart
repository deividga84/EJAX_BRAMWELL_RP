import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'theme/app_theme.dart';
import 'screens/auth_screens.dart';
import 'screens/main_screens.dart';
import 'screens/extra_screens.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Substitua pelas suas credenciais do Supabase
  await Supabase.initialize(
    url: 'https://yhynifhxfctjfpkrldhf.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InloeW5pZmh4ZmN0amZwa3JsZGhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4NjA4MzYsImV4cCI6MjA5MTQzNjgzNn0.TWRof9fLD6FspRcvyUtRadyZ2FKngPpiBXO6aQKv618',
  );

  runApp(const EjaxLauncherApp());
}

class EjaxLauncherApp extends StatelessWidget {
  const EjaxLauncherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EJAX BRAMWELL RP',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/home': (context) => const HomeScreen(),
        '/servers': (context) => const ServersScreen(),
        '/downloads': (context) => const DownloadsScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/admin': (context) => const AdminPanelScreen(),
      },
    );
  }
}
