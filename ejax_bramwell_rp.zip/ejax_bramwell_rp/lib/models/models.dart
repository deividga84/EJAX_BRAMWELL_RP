class UserModel {
  final String id;
  final String email;
  final String name;
  final String role;
  final String status;

  UserModel({required this.id, required this.email, required this.name, required this.role, required this.status});

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'],
    email: json['email'],
    name: json['name'],
    role: json['role'] ?? 'client',
    status: json['status'] ?? 'active',
  );
}

class ServerModel {
  final String id;
  final String name;
  final String ip;
  final int port;
  final String mode;
  final String status;
  final String? version;
  final String? description;
  final String? banner;

  ServerModel({required this.id, required this.name, required this.ip, required this.port, required this.mode, required this.status, this.version, this.description, this.banner});

  factory ServerModel.fromJson(Map<String, dynamic> json) => ServerModel(
    id: json['id'],
    name: json['name'],
    ip: json['ip'],
    port: json['port'],
    mode: json['mode'] ?? 'samp',
    status: json['status'] ?? 'online',
    version: json['version'],
    description: json['description'],
    banner: json['banner'],
  );
}

class FileItemModel {
  final String id;
  final String name;
  final String url;
  final String? version;
  final String category;
  final bool required;
  final String? hash;
  final double? sizeMb;
  final String? localPath;

  FileItemModel({required this.id, required this.name, required this.url, this.version, required this.category, required this.required, this.hash, this.sizeMb, this.localPath});

  factory FileItemModel.fromJson(Map<String, dynamic> json) => FileItemModel(
    id: json['id'],
    name: json['name'],
    url: json['url'],
    version: json['version'],
    category: json['category'],
    required: json['required'] ?? true,
    hash: json['hash'],
    sizeMb: json['size_mb']?.toDouble(),
    localPath: json['local_path'],
  );
}

class LauncherConfig {
  final String latestVersion;
  final bool maintenance;
  final String maintenanceMessage;
  final bool forceUpdate;
  final String? downloadUrl;
  final String launcherTitle;
  final String? bannerUrl;
  final String? supportUrl;

  LauncherConfig({required this.latestVersion, required this.maintenance, required this.maintenanceMessage, required this.forceUpdate, this.downloadUrl, required this.launcherTitle, this.bannerUrl, this.supportUrl});

  factory LauncherConfig.fromJson(Map<String, dynamic> json) => LauncherConfig(
    latestVersion: json['latest_version'] ?? '1.0.0',
    maintenance: json['maintenance'] ?? false,
    maintenanceMessage: json['maintenance_message'] ?? 'O launcher está em manutenção.',
    forceUpdate: json['force_update'] ?? false,
    downloadUrl: json['download_url'],
    launcherTitle: json['launcher_title'] ?? 'EJAX BRAMWELL RP',
    bannerUrl: json['banner_url'],
    supportUrl: json['support_url'],
  );
}
