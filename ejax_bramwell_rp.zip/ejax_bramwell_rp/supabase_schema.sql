create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key,
  email text,
  name text,
  role text default 'client',
  status text default 'active',
  created_at timestamp default now()
);

create table if not exists servers (
  id uuid primary key default gen_random_uuid(),
  name text,
  ip text,
  port int,
  mode text default 'samp',
  status text default 'online',
  version text,
  description text,
  banner text,
  active boolean default true,
  created_at timestamp default now()
);

create table if not exists news (
  id uuid primary key default gen_random_uuid(),
  title text,
  content text,
  image text,
  active boolean default true,
  created_at timestamp default now()
);

create table if not exists launcher_config (
  id uuid primary key default gen_random_uuid(),
  latest_version text,
  maintenance boolean default false,
  maintenance_message text default 'O launcher está em manutenção. Volte em breve.',
  force_update boolean default false,
  download_url text,
  launcher_title text default 'EJAX BRAMWELL RP',
  banner_url text,
  support_url text,
  created_at timestamp default now()
);

create table if not exists files (
  id uuid primary key default gen_random_uuid(),
  name text,
  url text,
  version text,
  category text,
  required boolean default true,
  hash text,
  size_mb numeric,
  active boolean default true,
  local_path text,
  created_at timestamp default now()
);

create table if not exists download_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  file_id uuid,
  status text,
  local_path text,
  downloaded_at timestamp default now()
);
