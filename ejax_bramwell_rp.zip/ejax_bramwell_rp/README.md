# EJAX BRAMWELL RP - Launcher Mobile

Este é um launcher profissional para o servidor SAMP Mobile EJAX BRAMWELL RP, desenvolvido em Flutter com backend Supabase. O aplicativo oferece uma experiência completa para os jogadores, permitindo o download de arquivos necessários, gerenciamento de dados do SAMP/GTA, acesso a notícias, servidores, login/cadastro e, futuramente, conexão direta ao servidor.

## Funcionalidades

- **Splash Screen:** Tela de carregamento inicial com o logo do servidor.
- **Autenticação:** Telas de Login e Cadastro com Supabase Auth.
- **Home Principal:** Visão geral com banner, status do launcher/servidor, notícias e botões de acesso rápido.
- **Servidores:** Lista de servidores com detalhes e opções de gerenciamento.
- **Downloads:** Sistema robusto para download de arquivos do SAMP/GTA, com barra de progresso, verificação de integridade e organização automática de pastas.
- **Gerenciador de Arquivos:** Prepara a estrutura de arquivos local e permite a seleção manual da pasta do GTA/SAMP.
- **Painel Admin:** Interface para gerenciar usuários, servidores, notícias, arquivos e configurações do launcher.
- **Sistema de Manutenção e Atualização:** Controle de manutenção e forçar atualização do aplicativo.
- **Identidade Visual:** Design gamer, moderno, escuro, limpo e premium, com detalhes em azul neon, laranja ou dourado.

## Stack Tecnológica

- **Frontend:** Flutter
- **Backend:** Supabase
- **Banco de Dados:** PostgreSQL (via Supabase)
- **Autenticação:** Supabase Auth
- **Armazenamento de Arquivos:** Supabase Storage
- **Cache Local:** SharedPreferences ou Hive
- **Requisições HTTP:** Dio
- **Gerenciamento de Caminhos:** Path Provider
- **Permissões Android:** Permission Handler

## Estrutura de Pastas do Projeto

```
lib/
  main.dart
  app/
    app.dart
  core/
    constants/
    errors/
    helpers/
    permissions/
  routes/
    app_routes.dart
  theme/
    app_theme.dart
  models/
    user_model.dart
    server_model.dart
    news_model.dart
    file_item_model.dart
    launcher_config_model.dart
    download_task_model.dart
  services/
    supabase_service.dart
    auth_service.dart
    server_service.dart
    news_service.dart
    file_service.dart
    download_service.dart
    version_service.dart
    maintenance_service.dart
    storage_service.dart
  repositories/
    auth_repository.dart
    server_repository.dart
    file_repository.dart
    news_repository.dart
  screens/
    splash/
    auth/
    client/
    admin/
    downloads/
    servers/
    profile/
    settings/
  widgets/
    gamer_button.dart
    gamer_card.dart
    progress_bar.dart
    status_badge.dart
  native_bridge/
    android_file_bridge.dart
    samp_bridge.dart
```

## Configuração do Supabase

### SQL Schema

O arquivo `supabase_schema.sql` contém o script para criar as tabelas necessárias no seu projeto Supabase:

```sql
create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key,
  email text,
  name text,
  role text default 'client',
  status text default 'active',
  created_at timestamp default now()
);

create table if not exists servers (
  id uuid primary key default gen_random_uuid(),
  name text,
  ip text,
  port int,
  mode text default 'samp',
  status text default 'online',
  version text,
  description text,
  banner text,
  active boolean default true,
  created_at timestamp default now()
);

create table if not exists news (
  id uuid primary key default gen_random_uuid(),
  title text,
  content text,
  image text,
  active boolean default true,
  created_at timestamp default now()
);

create table if not exists launcher_config (
  id uuid primary key default gen_random_uuid(),
  latest_version text,
  maintenance boolean default false,
  maintenance_message text default 'O launcher está em manutenção. Volte em breve.',
  force_update boolean default false,
  download_url text,
  launcher_title text default 'EJAX BRAMWELL RP',
  banner_url text,
  support_url text,
  created_at timestamp default now()
);

create table if not exists files (
  id uuid primary key default gen_random_uuid(),
  name text,
  url text,
  version text,
  category text,
  required boolean default true,
  hash text,
  size_mb numeric,
  active boolean default true,
  local_path text,
  created_at timestamp default now()
);

create table if not exists download_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  file_id uuid,
  status text,
  local_path text,
  downloaded_at timestamp default now()
);
```

### Supabase Storage

Crie os seguintes buckets no Supabase Storage para organizar seus arquivos:

- `launcher`
- `gta`
- `samp`
- `data`
- `images`
- `news`
- `banners`

**Organização Sugerida:**

- `samp/data/data_samp.zip`
- `samp/config/samp.cfg`
- `gta/models/gta3.img`
- `launcher/app-release.apk`
- `images/logo.png`
- `banners/home-banner.png`

## Instalação e Execução

1.  **Clone o Repositório:**
    ```bash
    git clone [URL_DO_REPOSITORIO]
    cd ejax_bramwell_rp
    ```

2.  **Configurar Supabase:**
    - Crie um novo projeto no [Supabase](https://supabase.io/).
    - Execute o `supabase_schema.sql` para criar as tabelas.
    - Crie os buckets de Storage conforme a seção acima.
    - Atualize `lib/main.dart` com sua `SUPABASE_URL` e `SUPABASE_ANON_KEY`.

3.  **Instalar Dependências:**
    ```bash
    flutter pub get
    ```

4.  **Executar o Aplicativo:**
    ```bash
    flutter run
    ```

## Build do APK

Para gerar o APK de release, utilize o comando:

```bash
flutter build apk --release
```

O APK gerado estará em `build/app/outputs/flutter-apk/app-release.apk`.

## Permissões Android

As seguintes permissões são necessárias e já estão configuradas no `AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
```

Para Android 11+ (API 30+), o aplicativo utilizará o Storage Access Framework para gerenciar o acesso a arquivos externos, conforme necessário.

## Segurança

- **Row Level Security (RLS):** Implemente RLS no Supabase para controlar o acesso aos dados.
- **Roles:** Defina roles (`client`, `admin`, `superadmin`) para gerenciar permissões de usuário.
- **Proteção de Rotas:** Valide a role do usuário antes de permitir acesso a painéis administrativos.
- **Tratamento de Erros:** Implemente tratamento de erros robusto em todo o aplicativo.
- **Chaves Sensíveis:** Não exponha chaves sensíveis no frontend, exceto a `anon key` do Supabase.

---

**Desenvolvido por Manus AI**
